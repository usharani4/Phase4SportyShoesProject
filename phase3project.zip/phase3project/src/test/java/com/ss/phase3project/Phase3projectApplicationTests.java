package com.ss.phase3project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3projectApplicationTests {

	@Test
	void contextLoads() {
	}

}
